# Crop-recommendation-using-machine-learning
This project aims to develop a crop recommendation system using a Random Forest machine learning model. The system uses a dataset containing information about soil type i.e. PH value and weather factors like temperature, humidity and rainfall to recommend the most suitable crops for a given location.
